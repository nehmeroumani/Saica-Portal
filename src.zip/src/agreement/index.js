import AgreementList from './list'
import UserIcon from '@material-ui/icons/People';

export default {
    list: AgreementList,
    icon: UserIcon,
};
