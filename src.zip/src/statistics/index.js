import UserList from './overview/list'
import UserIcon from '@material-ui/icons/PieChart';

export default {
    list: UserList,
    icon: UserIcon,
};
