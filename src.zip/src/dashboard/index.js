import DashboardComponent from './dashboard';

export const Dashboard = DashboardComponent;
