//export const Config = { apiUrl: 'https://localhost:44327' };

export const Config = { apiUrl: 'http://172.105.92.8:81' };