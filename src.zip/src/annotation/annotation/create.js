// import React from 'react';

// import { required, Create, SimpleForm, NumberInput, TextInput, BooleanField, BooleanInput, ReferenceInput, SelectArrayInput,ReferenceArrayInput } from 'react-admin';

// const UserCreate = (props) => (
//     <Create {...props}>
//         <SimpleForm>
//             <TextInput source="name" validate={required()} />
//             <NumberInput source="startTweetId" validate={required()} />
//             <NumberInput source="endTweetId" validate={required()} />
//             <ReferenceArrayInput source="userIds" reference="users" label="Users"     filter={{ role: 30 }} >
//                 <SelectArrayInput optionText="name" />
//             </ReferenceArrayInput>
//         </SimpleForm>
//     </Create>
// );

// export default UserCreate;

